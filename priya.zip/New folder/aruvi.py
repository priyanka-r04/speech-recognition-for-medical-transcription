import speech_recognition as sr
import pyttsx3
import keyboard
from pynput.mouse import Controller

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Initialize the recognizer
recognizer = sr.Recognizer()

# Initialize mouse controller for game actions
mouse = Controller()

# Function for speaking text (for feedback)
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Function to listen for voice commands
def listen_for_commands():
    with sr.Microphone() as source:
        print("Listening for commands...")
        recognizer.adjust_for_ambient_noise(source)  # Adjust to ambient noise levels
        audio = recognizer.listen(source)  # Listen to audio

        try:
            command = recognizer.recognize_google(audio)  # Convert speech to text using Google API
            print(f"You said: {command}")
            return command.lower()
        except sr.UnknownValueError:
            print("Sorry, I didn't understand that.")
            return None
        except sr.RequestError:
            print("Could not request results from Google Speech Recognition service.")
            return None

# Function to perform actions based on voice commands
def process_command(command):
    if command:
        if "move up" in command:
            print("Moving up")
            speak("Moving up")
            # You can simulate keyboard presses like 'w' for moving up
            keyboard.press('w')
            keyboard.release('w')

        elif "move down" in command:
            print("Moving down")
            speak("Moving down")
            # Simulate 's' for down
            keyboard.press('s')
            keyboard.release('s')

        elif "move left" in command:
            print("Moving left")
            speak("Moving left")
            # Simulate 'a' for left
            keyboard.press('a')
            keyboard.release('a')

        elif "move right" in command:
            print("Moving right")
            speak("Moving right")
            # Simulate 'd' for right
            keyboard.press('d')
            keyboard.release('d')

        elif "jump" in command:
            print("Jumping")
            speak("Jumping")
            # Simulate 'space' for jumping
            keyboard.press('space')
            keyboard.release('space')

        elif "shoot" in command:
            print("Shooting")
            speak("Shooting")
            # Simulate left mouse click for shooting
            mouse.click(Button.left)

        elif "exit" in command:
            print("Exiting game...")
            speak("Exiting game")
            return False  # To break out of the loop

    return True

# Main loop to continuously listen for voice commands
def main():
    while True:
        command = listen_for_commands()  # Get voice command
        if not process_command(command):  # Process command
            break  # Exit the loop if 'exit' is said

if __name__ == "__main__":
    main()
