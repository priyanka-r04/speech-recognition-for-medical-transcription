import speech_recognition as sr

# Initialize recognizer
recognizer = sr.Recognizer()

# Use the default microphone as the source
with sr.Microphone() as source:
    print("Adjusting for ambient noise... Please wait.")
    recognizer.adjust_for_ambient_noise(source)
    print("Listening for medical transcription...")

    audio = recognizer.listen(source)

    try:
        # You can also use recognize_google_cloud or others for better accuracy
        transcription = recognizer.recognize_google(audio)
        print("Transcription:")
        print(transcription)

        # Save to file
        with open("medical_transcript.txt", "w") as f:
            f.write(transcription)

    except sr.UnknownValueError:
        print("Could not understand the audio.")
    except sr.RequestError as e:
        print(f"Error with the service; {e}")
